using System;

using UnityEngine;

using UniRx;

using InputProviders.Player;
using Player.Structure;


namespace Mock
{
    [Obsolete]
    public class ParameterContainerMock : MonoBehaviour /*IPlayerParameterContainer*/
    {
        //[SerializeField] private UnityPlayerInputProviderMock _inputProvider;
        //[SerializeField] private GamePadInput input;

        private IPlayerInputProvider inputProvider;


        public bool isSprint { get; set; }  //������
        public LookDirection lookToDirection { get; private set; }

        public float jumpStrength { get; private set; }



        public void Awake()
        {
            //if (_inputProvider) inputProvider = _inputProvider;
            //else inputProvider = input;

            //�ړ������̕ϊ�
            inputProvider.onMoveInput.Subscribe(inputData =>
            {
                lookToDirection = ConvertMoveInputData(inputData);
            });

            //�W�����v���͂̕ϊ�
            inputProvider.onJumpInput.Subscribe(inputData =>
            {
                jumpStrength = inputData.magnitude;
            });
        }



        //�{����.�������Ŏg���ϊ�����
        public LookDirection ConvertMoveInputData(MoveInputData inputData)
        {
            Vector3 forward = Vector3.Scale(Camera.main.transform.forward, new Vector3(1, 0, 1)).normalized;
            Vector3 right = Vector3.Scale(Camera.main.transform.right, new Vector3(1, 0, 1)).normalized;
            Vector3 vec = (inputData.y * forward + inputData.x * right).normalized;

            return new LookDirection(vec.x, vec.z);
        }
    }
}

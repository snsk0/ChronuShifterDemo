using System;

using UnityEngine;

using Player.Behaviours;

namespace Mock
{
    [Obsolete]
    public class UnityGroundCheck : MonoBehaviour, IPlayerOnGrounded
    {
        [SerializeField] private float rayRange;    //ray�̒���
        [SerializeField] private new Rigidbody rigidbody;

        [SerializeField] private Animator animator;

        private bool isGrounding;   //�ێ��ϐ�   
        [SerializeField] private float isNotGroundingYVelocityThreshold; //y�������ړ����x��臒l

        //�֐�
        public bool IsOnGrounded()
        {
            return isGrounding;
        }



        //���t���[���X�V����
        private void Update()
        {
            //y���̈ړ���������Ȃ�n�ʂ��痣��Ă��邽��false��
            if(rigidbody.velocity.y > isNotGroundingYVelocityThreshold)
            {
                isGrounding = false;
                animator.SetFloat("FallSpeed", rigidbody.velocity.y);
                animator.SetBool("fall", true);
                return;
            }

            Debug.DrawRay(transform.position, Vector3.down * rayRange, Color.red);

            if (Physics.Raycast(transform.position, Vector3.down, rayRange))
            {
                isGrounding = true;
                animator.SetFloat("FallSpeed", rigidbody.velocity.y);
                animator.SetBool("fall", false);
            }
            else
            {
                isGrounding = false;
                animator.SetFloat("FallSpeed", rigidbody.velocity.y);
                animator.SetBool("fall", true);
            }
        }
    }
}

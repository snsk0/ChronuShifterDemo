using UnityEngine;
//using Chronus;

using UnityEngine.InputSystem;
using UniRx;
using System;

namespace Mock
{

    public enum ItemType
    {
        None,
        Current,
        Past
    }

    [Obsolete]
    public class PlayerHandleItem : MonoBehaviour
    {
        [SerializeField] private float rayRange;
        //private ChronusObject handlingObject;
        private GameObject handlingGameObject;
        [SerializeField] private Transform handlingPosition;
        [SerializeField] private PlayerInput playerInput;
        private GameObject parentCash;

        private Rigidbody handlingRigidBody;
        private RigidbodyInterpolation interpolate;

        private Subject<ItemType> onHandleItemSubject = new Subject<ItemType>();
        public IObservable<ItemType> onHandleItemEvent => onHandleItemSubject;




        private void Update()
        {
            bool input = false;
            if (playerInput != null) input = playerInput.currentActionMap["Interact"].WasPressedThisFrame();
            //Rayを飛ばす
            Debug.DrawRay(transform.position, transform.forward * rayRange, Color.red);

            /*
            //アイテム取得の判定
            if (Input.GetKeyDown(KeyCode.E) || input)
            {
                if (handlingObject == null)
                {
                    //raycast
                    RaycastHit hit;
                    if (Physics.Raycast(transform.position, transform.forward, out hit, rayRange))
                    {
                        //クロノスオブジェクトの取得
                        ChronusObject objects = hit.collider.GetComponent<ChronusObject>();
                        handlingRigidBody = hit.collider.GetComponent<Rigidbody>();
                        if (objects == null) return;

                        //イベント発行
                        switch (objects.chronusType)
                        {
                            case ObjectChronusType.current:
                                onHandleItemSubject.OnNext(ItemType.Current);
                                break;
                            case ObjectChronusType.past:
                                onHandleItemSubject.OnNext(ItemType.Past);
                                break;
                        }

                        objects.ToggleCarriedState(true);
                        handlingObject = objects;
                        handlingGameObject = hit.collider.gameObject;

                        parentCash = handlingGameObject.transform.parent.gameObject;
                        handlingGameObject.transform.parent = gameObject.transform;
                        handlingGameObject.transform.position = handlingPosition.position;

                        if (handlingRigidBody)
                        {
                            handlingRigidBody.isKinematic = true;
                            interpolate = handlingRigidBody.interpolation;
                            handlingRigidBody.interpolation = RigidbodyInterpolation.None;
                        }
                    }
                }


                else
                {
                    if (handlingRigidBody) handlingRigidBody.isKinematic = false;
                    handlingObject.ToggleCarriedState(false);
                    handlingGameObject.transform.parent = parentCash.transform;

                    handlingRigidBody.interpolation = interpolate;

                    handlingObject = null;
                    handlingGameObject = null;
                    handlingRigidBody = null;

                    onHandleItemSubject.OnNext(ItemType.None);
                }
            }*/
        }
    }
}

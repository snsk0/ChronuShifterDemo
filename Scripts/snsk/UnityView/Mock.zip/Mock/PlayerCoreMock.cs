using System;

using UnityEngine;

using Player;
using Player.Presenter;
using Player.States;
using FSMUtils;
using Animation.Presenter;

using Player.Behaviours;

using UnityView.Player.Behaviours;
using UnityView.Player.Animation;


namespace Mock
{
    [Obsolete]
    public class PlayerCoreMock : MonoBehaviour
    {
        //���b�N�R���|�[�l���g
        //[SerializeField] private UnityPlayerInputProviderMock inputProvider;
        //[SerializeField] private GamePadInput inputpad;
        [SerializeField] private UnityUpdateInputProvider updateProvider;

        [SerializeField] private PlayerLookMock look;
        [SerializeField] private PlayerMoveMock move;
        [SerializeField] private PlayerMover mover;
        [SerializeField] private ParameterContainerMock paramContainer;
        [SerializeField] private UnityGroundCheck ground;
        [SerializeField] private PlayerJump jump;

        [SerializeField] private PlayerAnimationController controller;


        //�R���e�L�X�g�n��
        private PlayerEventPresenter dispatcher;
        private PlayerFSMOwner fsmCore;


        private IReadOnlyObjectContainer container;

        //������
        private void Awake()
        {
            //�A�j���[�V�����v���[���^�[
            AnimationPresenter<PlayerAnimationType> presenter = new AnimationPresenter<PlayerAnimationType>(controller);
            presenter.RegisterAnimationTriggable(mover);



            //FSMUpdator��������
            FSMUpdateManager.Initialize(updateProvider);

            //�R���e�i�𐶐�
            ObjectContainer objectContainer = new ObjectContainer();
            objectContainer.AddObject(look);
            objectContainer.AddObject(move);
            objectContainer.AddObject(paramContainer);
            objectContainer.AddObject(ground);
            objectContainer.AddObject(jump);
            objectContainer.AddObject(mover);

            container = objectContainer;


            //fsm�R�A�𐶐�
            /*
            fsmCore = new PlayerFSMOwner(objectContainer, FSMUpdateManager.instance, fsm =>
            {
                //�X�e�[�g�}�V���̏�����
                /*
                PlayerGroundMoveParentState groundMoveParentState = new PlayerGroundMoveParentState();
                PlayerFallState fallState = new PlayerFallState();
                PlayerJumpState jumpState = new PlayerJumpState();

                fsm.AddState(groundMoveParentState);
                fsm.AddState(fallState);
                fsm.AddState(jumpState);
                fsm.SetInitialState(groundMoveParentState);

                fsm.AddTransition(groundMoveParentState, fallState, PlayerEvent.Fall);
                fsm.AddTransition(fallState, groundMoveParentState, PlayerEvent.End);
                fsm.AddTransition(groundMoveParentState, jumpState, PlayerEvent.Jump);
                fsm.AddTransition(jumpState, fallState, PlayerEvent.Fall);


                //groundedMove�w
                PlayerIdleState idleState = new PlayerIdleState();
                PlayerMoveState moveState = new PlayerMoveState();

                groundMoveParentState.innnerFSM.AddState(idleState);
                groundMoveParentState.innnerFSM.AddState(moveState);
                groundMoveParentState.innnerFSM.SetInitialState(idleState);

                groundMoveParentState.innnerFSM.AddTransition(idleState, moveState, PlayerEvent.Move);
                groundMoveParentState.innnerFSM.AddTransition(moveState, idleState, PlayerEvent.End);
                */
            //});
        

            //�f�B�X�p�b�`���[�𐶐�
            //if(inputProvider) dispatcher = new PlayerEventPresenter(fsmCore, inputProvider);
            //else dispatcher = new PlayerEventPresenter(fsmCore, inputpad);
        }

        private void Start()
        {
            fsmCore.StartFSM();
        }

        //�X�V����-�s�v
        void Update()
        {
            //Debug.Log(fsmCore.currentStateType);
            /*
            if(c > 10)
            {
                fsmCore.SendEvent(PlayerEvent.End);
            }
            */
        }
    }
}

using UnityEngine;
using UnityEngine.InputSystem;


using UniRx;

using InputProviders.Player;

using System;


namespace Mock{
    /*
    public class GamePadInput : MonoBehaviour, IPlayerInputProvider
    {
        [SerializeField] private PlayerInput playerInput;

        //�T�u�W�F�N�g
        private Subject<MoveInputData> moveSubject = new Subject<MoveInputData>();
        private Subject<JumpInputData> jumpSubject = new Subject<JumpInputData>();

        //�C�x���g�w�Ǘp
        public IObservable<MoveInputData> onMoveInput => moveSubject;
        public IObservable<JumpInputData> onJumpInput => jumpSubject;


        //Update
        private void Update()
        {


            Vector3 move = playerInput.currentActionMap["Move"].ReadValue<Vector2>();

            moveSubject.OnNext(new MoveInputData(move.x, move.y));


            if (playerInput.currentActionMap["Jump"].WasPressedThisFrame()) jumpSubject.OnNext(new JumpInputData(1.0f));
        }
    }
    */

}

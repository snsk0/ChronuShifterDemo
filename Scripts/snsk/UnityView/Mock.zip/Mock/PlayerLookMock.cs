using System;

using UnityEngine;

using Player.Behaviours;
using Player.Structure;


namespace Mock
{
    [Obsolete]
    public class PlayerLookMock : MonoBehaviour, IPlayerLock
    {
        [SerializeField] private float timeStep;
        [SerializeField] private new Rigidbody rigidbody;

        private Quaternion q;

        public LookDirection GetDirection()
        {
            Vector3 vec = gameObject.transform.forward;
            return new LookDirection(vec.x, vec.z);
        }

        public void Look(LookDirection direction)
        {
            //��]Quartanion�̌v�Z
            Vector3 vec = new Vector3(direction.x, 0, direction.y);
            vec.y = 0;
            q = Quaternion.LookRotation(vec, Vector3.up);
        }


        private void Awake()
        {
            q = transform.rotation;
        }
        private void Update()
        {
            //��]����
            rigidbody.MoveRotation(Quaternion.Lerp(transform.rotation, q, timeStep * Time.deltaTime));
            //transform.rotation = Quaternion.Lerp(transform.rotation, q, timeStep * Time.deltaTime);
        }
    }
}

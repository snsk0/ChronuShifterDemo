using System;

using UnityEngine;

using Player.Behaviours;
using Player.Structure;

namespace Mock
{
    [Obsolete]
    public class PlayerMoveMock : MonoBehaviour /*IPlayerMove*/
    {
        [SerializeField] private new Rigidbody rigidbody;
        [SerializeField] private float maxVelocity;
        [SerializeField] private float moveForceMultiplier;
        [SerializeField] private float maxAirVelocity;
        [SerializeField] private float airMoveStrength;

        [SerializeField] private UnityGroundCheck grounded;

        [SerializeField] private Animator animator;
        private string animationCode�@= "move";


        private Vector3 direction;
        private Vector3 airDir;


        public void Move(LookDirection direction)
        {
            this.direction = new Vector3(direction.x, 0, direction.y).normalized;
            animator.SetBool(animationCode, true);
        }

        public void AirMove(LookDirection direction)
        {
            airDir = new Vector3(direction.x, 0, direction.y).normalized;
        }


        public void FixedUpdate()
        {
            //�A�j���[�V�����Đ��̒�~(���͂��Ȃ������ꍇ�Ɏ~�߂�)
            if (direction == Vector3.zero) animator.SetBool(animationCode, false);

            if (!grounded.IsOnGrounded())
            {
                if (airDir == Vector3.zero) return;

                Vector3 vec = new Vector3(rigidbody.velocity.x, 0, rigidbody.velocity.z);
                if (vec.magnitude > maxAirVelocity)
                {
                    vec = vec.normalized * maxAirVelocity;                                     //�ō����ɏC��
                    rigidbody.velocity = new Vector3(vec.x, rigidbody.velocity.y, vec.z);   //y����velocity�ɑ��
                }
                else rigidbody.AddForce(airDir * airMoveStrength, ForceMode.Acceleration);

                airDir = Vector3.zero;
                return;
            }
            else
            {
                //�ړ��Ɋւ��Đ��������݈̂���
                Vector3 velocity = new Vector3(rigidbody.velocity.x, 0, rigidbody.velocity.z);


                float magnitude = maxVelocity - velocity.magnitude;
                rigidbody.AddForce(moveForceMultiplier * (direction * magnitude - velocity), ForceMode.Acceleration);

                direction = Vector3.zero;
            }
        }
    }
}

using UnityEngine;
using UnityEngine.InputSystem;

//using Chronus;

namespace Mock
{
    public class ChronusGamePad : MonoBehaviour
    {
        //[SerializeField] private ChronusManager manager;
        [SerializeField] private PlayerInput playerInput;


        // Update is called once per frame
        void Update()
        {
            if (playerInput == null || playerInput.gameObject.activeInHierarchy == false) return;
            //if (playerInput.currentActionMap["TimeShift"].WasPressedThisFrame()) manager.ChangeTime();
        }
    }
}

using System;

using UnityEngine;

using UniRx;

namespace Mock
{
    [Obsolete]
    public class UnityHandleItemPresenter : MonoBehaviour
    {
        [SerializeField] private PlayerHandleItem handleItem;
        //[SerializeField] private IntractCheck ui;

        /*
        private void Awake()
        {
            /*
            handleItem.onHandleItemEvent.Subscribe(type =>
            {
                switch (type)
                {
                    case ItemType.None:
                        ui.leaveItem();
                        break;
                    case ItemType.Current:
                        ui.intractBox();
                        break;
                    case ItemType.Past:
                        ui.intractBox2();
                        break;
                }
            });
            */
        }
        */
    }
}


using UnityEngine;

using UniRx;

using InputProviders.Player;
using System;

namespace Mock
{
    /*
    public class UnityPlayerInputProviderMock : MonoBehaviour, IPlayerInputProvider
    {
        //�T�u�W�F�N�g
        private Subject<MoveInputData> moveSubject = new Subject<MoveInputData>();
        private Subject<JumpInputData> jumpSubject = new Subject<JumpInputData>();


        //�C�x���g�w�Ǘp
        public IObservable<MoveInputData> onMoveInput => moveSubject;
        public IObservable<JumpInputData> onJumpInput => jumpSubject;


        //Update
        private void Update()
        {

            float x = Input.GetAxisRaw("Horizontal");
            float y = Input.GetAxisRaw("Vertical");

            moveSubject.OnNext(new MoveInputData(x, y));


            if (Input.GetKeyDown(KeyCode.Space)) jumpSubject.OnNext(new JumpInputData(1.0f));
        }
    }*/
}
